drop table menu_item;

create database truyum_schema;
use truyum_schema;

create table menu_item(
	menu_id int primary key auto_increment,
	menu_name varchar(45) not null,
    price varchar(45) not null,
    active varchar(45) not null,
    date_of_launch datetime not null,
    category varchar(45) not null,
    free_delivery varchar(45) not null
);

create table userID(
	user_id int primary key auto_increment,
    user_name varchar(45) not null,
    user_type varchar(45) not null
);

create table cart(
	cart_id int primary key auto_increment,
    menu_id int not null,
    user_id int not null,
    foreign key (menu_id) references menu_item(menu_id),
    foreign key (user_id) references userID(user_id)
);

