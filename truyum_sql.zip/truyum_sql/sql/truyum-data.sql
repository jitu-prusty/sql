#1.a
insert into truyum_schema.menu_item(
	menu_name, price, active, date_of_launch, category, free_delivery
)
values
("Sandwich",99.00,"Yes",'2017-03-15',"Main Course","Yes"),
("Burger",129.00,"Yes","2017-12-23","Main Course","No"),
("Pizza",149.00,"Yes","2017-08-21","Main Course","No"),
("French Fries",57.00,"No","2017-07-02","Staters","Yes"),
("Chocolate Brownie",32.00,"Yes","2022-11-02","Dessert","Yes");

#1.b
select menu_name, concat('Rs.',price) as price, active, date_of_launch, category, free_delivery 
from truyum_schema.menu_item;

#2
select menu_name, concat('Rs.',price) as price,  category, free_delivery 
from truyum_schema.menu_item
where active = 'yes' and date_of_launch < '2020-08-03';

#3.a
select menu_name, concat('Rs.',price) as price, active, date_of_launch, category, free_delivery 
from truyum_schema.menu_item
where menu_id = 1;

#3.b
update truyum_schema.menu_item
	set menu_name = 'pancake', price = 49.99, active = 'Yes', date_of_launch = '2017-07-17', category = 'Main Course', free_delivery = 'Yes'
where menu_id = 1;

#4
insert into truyum_schema.userID(user_name, user_type)
values('John', 'Admin'), ('Mary', 'Customer');

insert into truyum_schema.cart(menu_id, user_id)
values(1,2),(2,2),(3,2);

#5.a
select m.menu_name, m.free_delivery, m.price 
from truyum_schema.menu_item m
inner join truyum_schema.cart c on m.menu_id=c.menu_id
inner join truyum_schema.userID u on c.user_id=u.user_id
where c.user_id=2;

#5.b
select concat("Rs. ",cast(sum(m.price)as char)) as Total 
from truyum_schema.menu_item m
inner join truyum_schema.cart c on m.menu_id=c.menu_id
inner join truyum_schema.userID u on c.user_id=u.user_id
where c.user_id=2;

#6
delete from truyum_schema.cart
where 
menu_id=3
and 
user_id = 2;











